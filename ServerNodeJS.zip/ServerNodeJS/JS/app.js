/*
    RESTFul Service
    Twitter: @Hana897TRX
    Last Update: 23/10/2020
    v1.0.0
*/

var crypto = require('crypto');
var uuid = require('uuid');
var express = require('express');
var mysql = require('mysql');
var bodyParser = require('body-parser');

//PASSWORD ENCRYPT
var genRandomString = function(length){
    return crypto.randomBytes(Math.ceil(length/2))
        .toString('hex')
        .slice(0, length);
};

var sha512 = function(password, salt){
    var hash = crypto.createHmac('sha512', salt);
    hash.update(password);
    var value = hash.digest('hex');

    return {
        salt:salt,
        passwordHash:value
    };
};

function saltHashPassword(userPassword){
    var salt = genRandomString(16);
    var passwordData = sha512(userPassword, salt);
    return passwordData;
}

function checkHashPassword(userPassword, salt){
    let passwordData = sha512(userPassword, salt);
    return passwordData;
}

// Connect to MySQL
var con = mysql.createConnection(require('../JS/config'));

var app = express();
app.use(bodyParser.json()); // Accept JSON
app.use(bodyParser.urlencoded({extended: true})); // Accept URL Encoded params


//Register function
app.post('/register/', (req, res, next) =>{

    var post_data = req.body; // GetPOST params
    let uid = uuid.v4(); // Get UUID
    let plaint_password = post_data.password; // Get password from params
    let hash_data = saltHashPassword(plaint_password);
    let passToken = hash_data.passwordHash;  // Get hash value
    let salt = hash_data.salt; //Get salt

    let name = post_data.name;
    let username = post_data.username;
    let fechaNacimiento = post_data.fechaNacimiento;
    let matricula = post_data.matricula;
    let carrera = post_data.matricula;
    let ecoPuntos = post_data.ecoPuntos; 

    con.query('SELECT * FROM Persons WHERE username = ?',[username], function(err, result, fields){
        con.on('error', function(err){
            console.log('[MySQL ERROR]', err);
        });
        if(result && result.length){
            res.json('User already exists');
        }
        else{
            con.query('INSERT INTO `Persons`(`personName`, `username`, `fechaNacimiento`, `matricula`, `carrera`, `ecoPuntos`, `passToken`, `coreToken`) VALUES (?,?,?,?,?,?,?,?)', 
                [name, username, fechaNacimiento,matricula, carrera, ecoPuntos, passToken, salt], function(err, result, fields){
                con.on('error', function(err){
                    console.log('[MySQL ERROR]', err);
                    res.json('Register error: ', err);
                });
                res.json('Register successful');
            });
        }
    });
})

//LogIn Function
app.post('/login/', (req, res, next) => {
    let post_data = req.body;
    
    let user_password = post_data.password;
    let username = post_data.username;

    con.query('SELECT * FROM Persons WHERE username = ?', [username], function(err, result, fields){
        con.on('error', function(err){
            console.log('[MySQL ERROR]', err);
            res.json('Register error: ', err);
        });
        if(result && result.length){
            let passToken = result[0].passToken;
            let coreToken = result[0].coreToken;
            let log_hashed = checkHashPassword(user_password, coreToken).passwordHash;
            if(log_hashed == passToken)
                res.end(JSON.stringify(result[0]))  // If password is true, return all info of user
            else{
                res.end(JSON.stringify('Wrong user or password'));
            }
        }
        else{
            res.json('User not exist.');
        }
    })
})

// Start Server
app.listen(3000, ()=>{
    console.log('SERVER Restful running on port 3000');
})