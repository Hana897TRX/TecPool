let config = {
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'TecPool'
};

module.exports = config;